////////////////////////////////////////////////////////////////////////////////
// Main File:        cache2Drows.c
// This File:        cache2Drows.c
// Other Files:      cache1D.c, cache2Dcols.c
// Semester:         CS 354 Fall 2018
//
// Author:           David Zhu
// Email:            dzhu46@wisc.edu
// CS Login:         zhu
//
/////////////////////////// OTHER SOURCES OF HELP //////////////////////////////
//                   fully acknowledge and credit all sources of help,
//                   other than Instructors and TAs.
//
// Persons:          N/A
//
//
// Online sources:   N/A
////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int global[3000][500];

int main(int argc, char *argv[]){
  for (int row = 0; row < 500; row++) {
    for (int col = 0; col < 3000; col++) {
      global[row][col] = row + col;
    }
  }
}
