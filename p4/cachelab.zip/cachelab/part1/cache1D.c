////////////////////////////////////////////////////////////////////////////////
// Main File:        cache1D.c
// This File:        cache1D.c
// Other Files:      cache2D
// Semester:         CS 354 Fall 2018
//
// Author:           David Zhu
// Email:            dzhu46@wisc.edu
// CS Login:         zhu
//
/////////////////////////// OTHER SOURCES OF HELP //////////////////////////////
//                   fully acknowledge and credit all sources of help,
//                   other than Instructors and TAs.
//
// Persons:          N/A
//
//
// Online sources:   N/A
////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int global[100000];

int main(int argc, char *argv[]){
  for (int i = 0; i < 100000; i++) {
    global[i] = i;
  }
}
